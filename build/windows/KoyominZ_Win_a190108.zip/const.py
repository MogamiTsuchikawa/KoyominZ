UIs = ["Button", "TextBox", "Label",
               "CheckBox", "ComboBox", "ProgressBar"]
UIs_t_CS = ["Button", "TextBox", "Label",
               "CheckBox", "ComboBox", "ProgressBar"]
project_dir = ""
project_name = ""
project_kind = "None"
source_files = {} #辞書型の中にリスト入れ込み。辞書型のキー値は拡張子名